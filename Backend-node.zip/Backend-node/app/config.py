"""
App configuration, loaded from environment variables / .env file.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # e.g. mysql+pymysql://user:password@host:3306/banhji
    DATABASE_URL: str = "mysql+pymysql://root:password@localhost:3306/banhji"

    SECRET_KEY: str = "change-me"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 1 day

    class Config:
        env_file = ".env"


settings = Settings()